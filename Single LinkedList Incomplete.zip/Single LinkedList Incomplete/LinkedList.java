public class LinkedList<T> implements List<T>{
  private Node<T> first;
  private Node<T> last;

  public LinkedList(){
    first = null;
    last = null;
  }

  // Check to see if the linkedlist is empty.
  //The linnkedlist must be empty  if first is null!
  public boolean isEmpty(){
    return first ==null;
  }
  // we need to iterate through the LinkedList and on each
  //movement we add 1 to the counter. We should stop when we reach the end, i.e. when the current is null
  public int size(){
    int count=0;
    Node<T> current = first;
    while(current != null){
      count++;
      current = current.next;
    }
    return count;
  }
  public String toString(){
    String out = "";
    Node<T> p = first;
    while(p != null){
      out += p.element+", ";
      p = p.next;
    }
    return out;
  }
  public T remove(T el){
    // To be completed
    T found = el;
    return found;
  }

  /*
      Review the code below to checkout how to add an element at an index
  */
  public void add(int index, T el){
    if(index < 0 || index > size())throw new IndexOutOfBoundsException();

    if(index ==0 ){
      first = new Node<T>(el, first);
      if(last == null){
        last = first;
      }
    }else{
      Node<T> pred = first;
      for(int i=1;i <=index - 1;i++){
        pred = pred.next;
      }
      pred.next = new Node<T>(el, pred.next);
      if(pred.next.next == null){
        last = pred.next;
      }
    }
    return;
  }
  //We have two cases when adding in an element...
  public void add(T el){
    if(isEmpty()){
      first = new Node<T>(el);
      last = first;
    }else{
      last.next = new Node<T>(el);
      last = last.next;
    }
  }
  //Method to check if a n element exists within the linkedlist
  public boolean contains(T target){
    boolean found = false;
    Node<T> current = first;
    while(current != null){
      if(current.element == target){
        found = true;
      }
      current = current.next;
    }
    return found;
  }
/*
  This method adds an element before a target element
  We need to find the element...
*/
  public void addBefore(T target, T elem) {

  // to be completed...
}
  public void addAfter(T target, T elem) {

  // to be completed...
}
  public static void main(String [] args){
    LinkedList<String> linked = new LinkedList<>();
    linked.add("apple");
    linked.add("Orange");
    linked.add("Banana");
    linked.add("Pear");
    linked.add("Kiwi");
    System.out.println("---------------------------");
    System.out.println("The sie of the linked list is :: "+linked.size());
    System.out.println(linked);
    System.out.println("---------------------------");
    linked.remove("Orange");
    linked.addAfter("apple", "Grape");
    System.out.println(linked);
    System.out.println("The sie of the linked list is :: "+linked.size());
    System.out.println("---------------------------");
  }


}
