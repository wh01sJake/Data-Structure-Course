package com.mycompany.mavenproject1;

public class MyWeirdList {
    MovieNode head;
    MovieNode last;
    int iSize = 0;
    
    public MyWeirdList(){
        head = null;
        last = null;
    }
    
    public boolean isEmpty(){
        return size() == 0;
    }
    
    public int size(){
        if(head == null){
            return 0;
        }else{
            MovieNode currNode = head;
            while (currNode != null){
                iSize++;
                currNode = currNode.next;
            }
            return iSize;
        }
        
    }
    
    
    public MovieNode getHead() {
        return head;
    }

    public void setHead(MovieNode head) {
        this.head = head;
    }

    public MovieNode getLast() {
        return last;
    }

    public void setLast(MovieNode last) {
        this.last = last;
    }
    
}
