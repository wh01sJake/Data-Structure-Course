package com.mycompany.mavenproject1;

public class MovieNode {

    Movie element;
    MovieNode next;

    public MovieNode(Movie inElement, MovieNode inNext) {
        element = inElement;
        next = inNext;
    }

    @Override
    public String toString() {
        return element.toString();
    }

    public Movie getElement() {
        return element;
    }

    public void setElement(Movie element) {
        this.element = element;
    }

    public MovieNode getNext() {
        return next;
    }

    public void setNext(MovieNode next) {
        this.next = next;
    }

}
