package com.mycompany.mavenproject1;

public class Mavenproject1 {

    public static void main(String[] args) {      
        Movie myMovie1 = new Movie("Inception", "Great movie", "Action", 160, 5);
        
        MovieNode myMovieNode = new MovieNode(myMovie, null);
        
         System.out.println(myMovie.toString());   
        
         //average rating
         int iTotalRating = 0;
         for(iCount = 1 to size()){
            iTotalRating += myMovie[iCount].iRating;
         }
         return iTotalRating / size();
         

      //genre
         String sSearchForGenre = "Action";
         String sResult = "";
         for(iCount = 1 to size()){
            if(sSearchForGenre.equals(myMovie[iCount].sGenre)){
                sResult += myMovie[iCount].sTitle + "\n";
            }
         }
         return sResult;

         
    }
}
