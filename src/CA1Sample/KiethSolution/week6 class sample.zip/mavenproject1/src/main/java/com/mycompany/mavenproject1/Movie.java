package com.mycompany.mavenproject1;

public class Movie {
    String sTitle;
    String sDescription;
    String sGenre;
    int iDuration;
    int iRating;

    public Movie(String sInTitle, String sInDescription, String sInGenre, int iInDuration, int iInRating) {
        sTitle = sInTitle;
        sDescription = sInDescription;
        sGenre = sInGenre;
        iDuration = iInDuration;
        iRating = iInRating;
    }  

    @Override
    public String toString(){
        String sMessage = "The title is " + sTitle + "\nDescription " + sDescription;
        return sMessage;
    }
    
    public String getsTitle() {
        return sTitle;
    }

    public void setsTitle(String sTitle) {
        this.sTitle = sTitle;
    }

    public String getsDescription() {
        return sDescription;
    }

    public void setsDescription(String sDescription) {
        this.sDescription = sDescription;
    }

    public String getsGenre() {
        return sGenre;
    }

    public void setsGenre(String sGenre) {
        this.sGenre = sGenre;
    }

    public int getiDuration() {
        return iDuration;
    }

    public void setiDuration(int iDuration) {
        this.iDuration = iDuration;
    }

    public int getiRating() {
        return iRating;
    }

    public void setiRating(int iRating) {
        this.iRating = iRating;
    }    
}
